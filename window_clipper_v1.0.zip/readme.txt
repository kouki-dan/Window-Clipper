
/******************************
* YouTube Repeater for Chrome *
******************************/

YouTubeをリピートできるようにするクロームエクステンションです。

以下のURLからインストールできます。
https://chrome.google.com/webstore/detail/youtube-repeater/lnpobfknjaodigeaeiipmadlelgccfdo

参考
Youtube JavaSript Player APIリファレンス
https://developers.google.com/youtube/js_api_reference?hl=ja

